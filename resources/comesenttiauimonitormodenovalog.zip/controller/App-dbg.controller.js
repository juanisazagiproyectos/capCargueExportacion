sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.esenttia.uimonitormodenovalog.controller.App", {
        onInit() {
        }
      });
    }
  );
  